import React from "react";

function Greeting() {
  return (
    <div className="greeting">
      <h1>WELCOME TO MERN LAB</h1> 
    </div>
  );
}

export default Greeting;
